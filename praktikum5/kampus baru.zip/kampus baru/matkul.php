<?php
include 'koneksi.php'; 
?>
<!DOCTYPE html>
<html>
<head>
    <title>Daftar Mata Kuliah</title>
    <style>
        body {font-family: Arial; background: #f3f6fb; padding: 20px;}
        h2 {color: #007bff;}
        table {width: 100%; border-collapse: collapse; margin-top: 20px; background: white;}
        th, td {border: 1px solid #ddd; padding: 10px; text-align: left;}
        th {background-color: #007bff; color: white;}
        .btn-tambah {display: inline-block; padding: 10px 15px; background: #28a745; color: white; text-decoration: none; border-radius: 5px;}
        .btn-tambah:hover {background: #1e7e34;}
        .aksi a {margin-right: 5px; color: #007bff; text-decoration: none;}
    </style>
</head>
<body>

<h2>Daftar Mata Kuliah</h2>
 <a href="index.php">< kembali</a> <br><br>
<a href="tambah_mk.php" class="btn-tambah">+ Tambah Mata Kuliah Baru</a>
<hr>

<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Kode MK</th>
            <th>Nama Mata Kuliah</th>
            <th>SKS</th>
            <th>Program Studi</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php
        // Query menggunakan JOIN untuk menggabungkan data Mata Kuliah (mk) dan Prodi (p)
        $query = "SELECT mk.id_matkul, mk.kode_matkul, mk.nama_matkul, mk.sks, p.nama_prodi 
                  FROM tb_matkul mk
                  JOIN tb_prodi p ON mk.id_prodi = p.id_prodi
                  ORDER BY p.nama_prodi, mk.kode_matkul ASC";
                  
        $result = $koneksi->query($query);
        $no = 1;

        if ($result && $result->num_rows > 0) {
            // Looping untuk menampilkan setiap baris data
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $no++ . "</td>";
                echo "<td>" . htmlspecialchars($row['kode_matkul']) . "</td>";
                echo "<td>" . htmlspecialchars($row['nama_matkul']) . "</td>";
                echo "<td>" . htmlspecialchars($row['sks']) . "</td>";
                echo "<td>" . htmlspecialchars($row['nama_prodi']) . "</td>"; 
                echo "<td class='aksi'>";
                // Tautan Edit dan Hapus (Anda perlu membuat file edit_matkul.php dan hapus_matkul.php)
                echo "<a href='edit_mk.php?id=" . $row['id_matkul'] . "'>Edit</a> | ";
                echo "<a href='hapus_matkul.php?id=" . $row['id_matkul'] . "' onclick=\"return confirm('Yakin ingin menghapus data ini?')\">Hapus</a>";
                echo "</td>";
                echo "</tr>";
            }
        } else {
            // Jika tidak ada data
            echo "<tr><td colspan='6' style='text-align: center;'>Belum ada data mata kuliah.</td></tr>";
        }

        // Bebaskan hasil query
        if (isset($result)) {
             $result->free();
        }
        ?>
    </tbody>
</table>

</body>
</html>