<?php
include 'koneksi.php';

// Ambil ID mahasiswa dari URL
$id = $_GET['id'] ?? 0;

// Pastikan ID valid
if ($id == 0) {
    echo "<script>alert('ID mahasiswa tidak ditemukan!');window.location='mahasiswa.php';</script>";
    exit;
}

// Hapus data dari tabel mahasiswa
$hapus = mysqli_query($koneksi, "DELETE FROM tb_mahasiswa WHERE id_mahasiswa='$id'");

// Cek hasil query
if ($hapus) {
    echo "<script>
        alert('Data mahasiswa berhasil dihapus!');
        window.location='mahasiswa.php';
    </script>";
} else {
    echo "<script>
        alert('Gagal menghapus data! Coba lagi.');
        window.location='mahasiswa.php';
    </script>";
}
?>