<?php include 'koneksi.php'?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mahasiswa</title>
    <style>
        body {font-family: Arial; background: #f6f8fa; padding: 20px;}
        h2 {color: #007bff;}
        table {border-collapse: collapse; width: 100%; background: #fff;}
        th, td {border: 1px solid #ddd; padding: 8px;}
        th {background: #007bff; color: white;}
        a {text-decoration: none; color: #007bff;}
        a:hover {text-decoration: underline;}
        .btn {padding: 6px 10px; background: #007bff; color: white; border-radius: 5px;}
        .btn:hover {background: #0056b3;}
    </style>
</head>
<body>
    <a href="index.php">< kembali</a> <br><br>
    <a href="tambah_mahasiswa.php">+tambah mahasiswa</a>
    <h2>Data Mahasiswa</h2>
   <br><br>
   <table>
    <tr>
        <th>No</th>
        <th>NIM</th>
        <th>Nama</th>
        <th>Prodi</th>
        <th>Alamat</th>
        <th>Username</th>
        <th>Password</th>
        <th>Aksi</th>
    </tr>
    <?php
    $no=1;
     $query = mysqli_query($koneksi, "SELECT m.*, p.nama_prodi 
                                     FROM tb_mahasiswa m 
                                     LEFT JOIN tb_prodi p ON m.id_prodi = p.id_prodi 
                                     ORDER BY id_mahasiswa DESC");
    while ($data = mysqli_fetch_array($query)) {
      echo "<tr>
            <td>$no</td>
            <td>$data[nim]</td>
            <td>$data[nama]</td>
            <td>$data[nama_prodi]</td>
            <td>$data[alamat]</td>
            <td>$data[username]</td>
            <td>$data[password]</td>
            <td>
                <a href='edit_mahasiswa.php?id=$data[id_mahasiswa]'>Edit</a> |
                <a href='hapus_mahasiswa.php?id=$data[id_mahasiswa]' onclick='return confirm(\"Yakin hapus?\")'>Hapus</a>
            </td>
        </tr>";
        $no++;
    }
    ?>
   </table>
</body>
</html>