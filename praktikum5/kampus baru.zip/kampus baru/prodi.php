<?php
include 'koneksi.php'; 
?>
<!DOCTYPE html>
<html>
<head>
    <title>Daftar Program Studi</title>
    <style>
        body {font-family: Arial; background: #f3f6fb; padding: 20px;}
        h2 {color: #007bff;}
        table {width: 60%; border-collapse: collapse; margin-top: 20px; background: white;}
        th, td {border: 1px solid #ddd; padding: 10px; text-align: left;}
        th {background-color: #007bff; color: white;}
        .btn-tambah {display: inline-block; padding: 10px 15px; background: #28a745; color: white; text-decoration: none; border-radius: 5px;}
        .btn-tambah:hover {background: #1e7e34;}
        .aksi a {margin-right: 5px; color: #007bff; text-decoration: none;}
    </style>
</head>
<body>

<h2>Daftar Program Studi</h2>
<a href="index.php">< kembali</a> <br><br>
<a href="tambah_prodi.php" class="btn-tambah">+ Tambah Program Studi</a>
<hr>

<table>
    <thead>
        <tr>
            <th>No</th>
            <th>ID Prodi</th>
            <th>Nama Program Studi</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $query = "SELECT * FROM tb_prodi ORDER BY nama_prodi ASC";
                  
        $result = $koneksi->query($query);
        $no = 1;

        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $no++ . "</td>";
                echo "<td>" .($row['id_prodi']) . "</td>";
                echo "<td>" .($row['nama_prodi']) . "</td>";
                
                echo "<td class='aksi'>";

                echo "<a href='edit_prodi.php?id=" . $row['id_prodi'] . "'>Edit</a> | ";
                echo "<a href='hapus_prodi.php?id=" . $row['id_prodi'] . "' onclick=\"return confirm('Menghapus Prodi akan mempengaruhi Mahasiswa dan Mata Kuliah yang terkait. Yakin?')\">Hapus</a>";
                echo "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4' style='text-align: center;'>Belum ada data Program Studi.</td></tr>";
        }
        if (isset($result)) {
             $result->free();
        }
        ?>
    </tbody>
</table>

</body>
</html>