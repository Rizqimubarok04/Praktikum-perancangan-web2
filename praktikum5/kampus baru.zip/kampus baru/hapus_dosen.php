<?php
include 'koneksi.php';

// Ambil ID dosen dari URL
$id = $_GET['id'] ?? 0;

// Pastikan ID valid
if ($id == 0) {
    echo "<script>alert('ID dosen tidak ditemukan!');window.location='dosen.php';</script>";
    exit;
}

// Hapus data dari tabel dosen
$hapus = mysqli_query($koneksi, "DELETE FROM tb_dosen WHERE id_dosen='$id'");

// Cek hasil query
if ($hapus) {
    echo "<script>
        alert('Data dosen berhasil dihapus!');
        window.location='dosen.php';
    </script>";
} else {
    echo "<script>
        alert('Gagal menghapus data! Coba lagi.');
        window.location='dosen.php';
    </script>";
}
?>