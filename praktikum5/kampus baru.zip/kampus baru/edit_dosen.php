<?php
include 'koneksi.php';

// Ambil ID dari URL
$id = $_GET['id'] ?? 0;

// Ambil data mahasiswa berdasarkan id
$query = mysqli_query($koneksi, "SELECT * FROM tb_dosen WHERE id_dosen ='$id'");
$data = mysqli_fetch_assoc($query);

// Jika data tidak ditemukan
if (!$data) {
    echo "Data tidak ditemukan!";
    exit;
}

// Proses update data saat tombol submit ditekan
if (isset($_POST['update'])) {
    $nip = $_POST['nip'];
    $nama_dosen = $_POST['nama_dosen'];
    $id_prodi = $_POST['id_prodi'] ?? null; // Validasi foreign key
    $username = $_POST['username'];
    $no_hp = $_POST['no_hp'];

    if ($id_prodi === null) {
        echo "<script>alert('Prodi belum dipilih!');</script>";
    } else {
        // Update ke database
        $update = mysqli_query($koneksi, "UPDATE tb_dosen SET 
            nip='$nip',
            nama_dosen ='$nama_dosen',
            id_prodi='$id_prodi',
            username='$username',
            no_hp='$no_hp'
            WHERE id_dosen='$id'");

        if ($update) {
            echo "<script>alert('Data berhasil diupdate!');window.location='dosen.php';</script>";
        } else {
            echo "Gagal update data: " . mysqli_error($koneksi);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Data Dosen</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f7fb;
            padding: 20px;
        }
        h2 {
            color: #0056d6;
        }
        form {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            width: 400px;
            box-shadow: 0 0 5px rgba(0,0,0,0.2);
        }
        input, select {
            width: 100%;
            padding: 8px;
            margin: 8px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            background-color: #0056d6;
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            border-radius: 5px;
        }
        button:hover {
            background-color: #003e9e;
        }
        a {
            text-decoration: none;
            color: #0056d6;
        }
    </style>
</head>
<body>

    <h2>Edit Data Dosen</h2>

    <form method="POST">
        <label>NIP</label>
        <input type="text" name="nip" value="<?= htmlspecialchars($data['nip']); ?>" required>

        <label>Nama Dosen</label>
        <input type="text" name="nama_dosen" value="<?= htmlspecialchars($data['nama_dosen']); ?>" required>

        <label>Program Studi</label>
        <select name="id_prodi" required>
            <option value="">-- Pilih Prodi --</option>
            <?php
            $tb_prodi = mysqli_query($koneksi, "SELECT * FROM tb_prodi");
            while ($p = mysqli_fetch_assoc($tb_prodi)) {
                $selected = ($p['id_prodi'] == $data['id_prodi']) ? 'selected' : '';
                echo "<option value='{$p['id_prodi']}' $selected>{$p['nama_prodi']}</option>";
            }
            ?>
        </select>

        <label>Username</label>
        <input type="text" name="username" value="<?= htmlspecialchars($data['username']); ?>" required>

        <label>No HP</label>
        <input type="text" name="no_hp" value="<?= htmlspecialchars($data['no_hp']); ?>" required>

        <button type="submit" name="update">Simpan Perubahan</button>
        <a href="dosen.php">Kembali</a>
    </form>

</body>
</html>