<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah Mahasiswa</title>
    <style>
        body {font-family: Arial; background: #f6f9ff; padding: 20px;}
        form {background: white; padding: 20px; border-radius: 10px; width: 400px;}
        input, select, textarea {width: 100%; padding: 8px; margin: 5px 0;}
        input[type=submit] {background: #007bff; color: white; border: none; padding: 10px;}
        input[type=submit]:hover {background: #0056b3;}
    </style>
</head>
<body>

<h2>Tambah Mahasiswa</h2>

<form method="post">
    NIM:
    <input type="text" name="nim" required>
    Nama:
    <input type="text" name="nama" required>
    Program Studi:
    <select name="id_prodi">
        <?php
        $tb_prodi = mysqli_query($koneksi, "SELECT * FROM tb_prodi");
        while ($p = mysqli_fetch_array($tb_prodi)) {
            echo "<option value='$p[id_prodi]'>$p[nama_prodi]</option>";
        }
        ?>
    </select>
    Alamat:
    <textarea name="alamat"></textarea>
    Username:
    <input type="text" name="username" required>
    Password:
    <input type="text" name="password" required>
    <input type="submit" name="simpan" value="Simpan Data">
</form>

<?php
if (isset($_POST['simpan'])) {
    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $id_prodi = $_POST['id_prodi'];
    $alamat = $_POST['alamat'];
    $username = $_POST['username'];
    $password = $_POST['password'];


    mysqli_query($koneksi, "INSERT INTO tb_mahasiswa(nim, nama, id_prodi, alamat, username, password)
                            VALUES ('$nim', '$nama', '$id_prodi', '$alamat', '$username', '$password')");
    header("Location: mahasiswa.php");
}
?>

<br>
<a href="mahasiswa.php">← Kembali</a>

</body>
</html>