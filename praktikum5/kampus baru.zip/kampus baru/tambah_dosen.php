<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah Dosen</title>
    <style>
        body {font-family: Arial; background: #f6f9ff; padding: 20px;}
        form {background: white; padding: 20px; border-radius: 10px; width: 400px;}
        input, select, textarea {width: 100%; padding: 8px; margin: 5px 0;}
        input[type=submit] {background: #007bff; color: white; border: none; padding: 10px;}
        input[type=submit]:hover {background: #0056b3;}
    </style>
</head>
<body>

<h2>Tambah Dosen</h2>

<form method="post">
    NIP:
    <input type="text" name="nip" required>
    Nama Dosen:
    <input type="text" name="nama_dosen" required>
    Program Studi:
    <select name="id_prodi">
        <?php
        $tb_prodi = mysqli_query($koneksi, "SELECT * FROM tb_prodi");
        while ($p = mysqli_fetch_array($tb_prodi)) {
            echo "<option value='$p[id_prodi]'>$p[nama_prodi]</option>";
        }
        ?>
    </select>
    Username:
    <input type="text" name="username" required>
    No HP:
    <input type="text" name="no_hp" required>
    <input type="submit" name="simpan" value="Simpan Data">
</form>

<?php
if (isset($_POST['simpan'])) {
    $nip = $_POST['nip'];
    $nama_dosen = $_POST['nama_dosen'];
    $id_prodi = $_POST['id_prodi'];
    $username = $_POST['username'];
    $no_hp = $_POST['no_hp'];


    mysqli_query($koneksi, "INSERT INTO tb_dosen(nip, nama_dosen, id_prodi, username, no_hp)
                            VALUES ('$nip', '$nama_dosen', '$id_prodi', '$username', '$no_hp')");
    header("Location: dosen.php");
}
?>

<br>
<a href="dosen.php">← Kembali</a>

</body>
</html>