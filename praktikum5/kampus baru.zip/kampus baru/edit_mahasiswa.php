<?php
include 'koneksi.php';

// Ambil ID dari URL
$id = $_GET['id'] ?? 0;

// Ambil data mahasiswa berdasarkan id
$query = mysqli_query($koneksi, "SELECT * FROM tb_mahasiswa WHERE id_mahasiswa ='$id'");
$data = mysqli_fetch_assoc($query);

// Jika data tidak ditemukan
if (!$data) {
    echo "Data tidak ditemukan!";
    exit;
}

// Proses update data saat tombol submit ditekan
if (isset($_POST['update'])) {
    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $id_prodi = $_POST['id_prodi'] ?? null; // Validasi foreign key
    $alamat = $_POST['alamat'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($id_prodi === null) {
        echo "<script>alert('Prodi belum dipilih!');</script>";
    } else {
        // Update ke database
        $update = mysqli_query($koneksi, "UPDATE tb_mahasiswa SET 
            nim='$nim',
            nama ='$nama',
            id_prodi='$id_prodi',
            alamat='$alamat',
            username='$username',
            password='$password'
            WHERE id_mahasiswa='$id'");

        if ($update) {
            echo "<script>alert('Data berhasil diupdate!');window.location='mahasiswa.php';</script>";
        } else {
            echo "Gagal update data: " . mysqli_error($koneksi);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Data Mahasiswa</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f7fb;
            padding: 20px;
        }
        h2 {
            color: #0056d6;
        }
        form {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            width: 400px;
            box-shadow: 0 0 5px rgba(0,0,0,0.2);
        }
        input, select {
            width: 100%;
            padding: 8px;
            margin: 8px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            background-color: #0056d6;
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            border-radius: 5px;
        }
        button:hover {
            background-color: #003e9e;
        }
        a {
            text-decoration: none;
            color: #0056d6;
        }
    </style>
</head>
<body>

    <h2>Edit Data Mahasiswa</h2>

    <form method="POST">
        <label>NIM</label>
        <input type="text" name="nim" value="<?= htmlspecialchars($data['nim']); ?>" required>

        <label>Nama</label>
        <input type="text" name="nama" value="<?= htmlspecialchars($data['nama']); ?>" required>

        <label>Program Studi</label>
        <select name="id_prodi" required>
            <option value="">-- Pilih Prodi --</option>
            <?php
            $tb_prodi = mysqli_query($koneksi, "SELECT * FROM tb_prodi");
            while ($p = mysqli_fetch_assoc($tb_prodi)) {
                $selected = ($p['id_prodi'] == $data['id_prodi']) ? 'selected' : '';
                echo "<option value='{$p['id_prodi']}' $selected>{$p['nama_prodi']}</option>";
            }
            ?>
        </select>

        <label>Alamat</label>
        <input type="text" name="alamat" value="<?= htmlspecialchars($data['alamat']); ?>" required>

        <label>Username</label>
        <input type="text" name="username" value="<?= htmlspecialchars($data['username']); ?>" required>

        <label>Password</label>
        <input type="text" name="password" value="<?= htmlspecialchars($data['password']); ?>" required>

        <button type="submit" name="update">Simpan Perubahan</button>
        <a href="mahasiswa.php">Kembali</a>
    </form>

</body>
</html>