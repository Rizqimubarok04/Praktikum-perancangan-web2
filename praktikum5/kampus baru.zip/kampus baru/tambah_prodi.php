<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah Prodi</title>
    <style>
        body {font-family: Arial; background: #f6f9ff; padding: 20px;}
        form {background: white; padding: 20px; border-radius: 10px; width: 400px;}
        input, select, textarea {width: 100%; padding: 8px; margin: 5px 0;}
        input[type=submit] {background: #007bff; color: white; border: none; padding: 10px;}
        input[type=submit]:hover {background: #0056b3;}
    </style>
</head>
<body>

<h2>Tambah Prodi</h2>

<form method="post">
    Program Studi:
    <input type="text" name="nama_prodi" required>
    Fakultas:
    <input type="text" name="fakultas" required>
    <input type="submit" name="simpan" value="Simpan Data">
</form>

<?php
if (isset($_POST['simpan'])) {
    $nama_prodi = $_POST['nama_prodi'];
    $fakultas = $_POST['fakultas'];


    mysqli_query($koneksi, "INSERT INTO tb_prodi(nama_prodi, fakultas)
                            VALUES ('$nama_prodi', '$fakultas')");
    header("Location: prodi.php");
}
?>

<br>
<a href="prodi.php">← Kembali</a>

</body>
</html>