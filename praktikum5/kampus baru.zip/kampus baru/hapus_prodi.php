<?php
include 'koneksi.php';

// Ambil ID prodi dari URL
$id = $_GET['id'] ?? 0;

// Pastikan ID valid
if ($id == 0) {
    echo "<script>alert('ID dosen tidak ditemukan!');window.location='prodi.php';</script>";
    exit;
}

// Hapus data dari tabel prodi
$hapus = mysqli_query($koneksi, "DELETE FROM tb_prodi WHERE id_prodi='$id'");

// Cek hasil query
if ($hapus) {
    echo "<script>
        alert('Data Prodi berhasil dihapus!');
        window.location='prodi.php';
    </script>";
} else {
    echo "<script>
        alert('Gagal menghapus data! Coba lagi.');
        window.location='prodi.php';
    </script>";
}
?>