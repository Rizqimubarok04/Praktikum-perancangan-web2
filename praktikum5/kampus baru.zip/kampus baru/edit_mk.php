<?php
include 'koneksi.php';

// Ambil ID dari URL
$id = $_GET['id'] ?? 0;

// Ambil data mahasiswa berdasarkan id
$query = mysqli_query($koneksi, "SELECT * FROM tb_matkul WHERE id_matkul ='$id'");
$data = mysqli_fetch_assoc($query);

// Jika data tidak ditemukan
if (!$data) {
    echo "Data tidak ditemukan!";
    exit;
}

// Proses update data saat tombol submit ditekan
if (isset($_POST['update'])) 
    $nama_prodi = $_POST['nama_prodi'];
    $id_prodi = $_POST['id_prodi'] ; // Validasi foreign key
    $fakultas = $_POST['fakultas'];

    if ($id_prodi) {
        echo "<script>alert('Prodi belum dipilih!');</script>";
    } else {
        // Update ke database
        $update = mysqli_query($koneksi, "UPDATE tb_prodi SET 
            nama_prodi ='$nama_prodi'
            id_prodi='$id_prodi'
            fakultas='$fakultas'
            WHERE id_prodi='$id'");

        if ($update) {
            echo "<script>alert('Data berhasil diupdate!');window.location='prodi.php';</script>";
        } else {
            echo "Gagal update data: " . mysqli_error($koneksi);
        }
    }
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Data Prodi</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f7fb;
            padding: 20px;
        }
        h2 {
            color: #0056d6;
        }
        form {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            width: 400px;
            box-shadow: 0 0 5px rgba(0,0,0,0.2);
        }
        input, select {
            width: 100%;
            padding: 8px;
            margin: 8px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            background-color: #0056d6;
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            border-radius: 5px;
        }
        button:hover {
            background-color: #003e9e;
        }
        a {
            text-decoration: none;
            color: #0056d6;
        }
    </style>
</head>
<body>

    <h2>Edit Data Prodi</h2>

    <form method="POST">
        <label>Program Studi</label>
        <input type="text" name="nama_prodi" value="<?= htmlspecialchars($data['nama_prodi']); ?>" required>

        <label>Fakultas</label>
        <input type="text" name="fakultas" value="<?= htmlspecialchars($data['fakultas']); ?>" required>
        <button type="submit" name="update">Simpan Perubahan</button>
        <a href="prodi.php">Kembali</a>
    </form>

</body>
</html>