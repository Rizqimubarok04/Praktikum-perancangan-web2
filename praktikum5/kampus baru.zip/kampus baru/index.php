<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kampus</title>
    <style>
    body { font-family: Arial; background: #eef3f7; margin: 0; }
    header { background: #007bff; color: white; text-align: center; padding: 20px; }
    nav { 
        background: white; 
        display: flex; 
        justify-content: center; 
        gap: 15px; 
        padding: 10px; 
        border-bottom: 1px solid #ddd; 
    }
    .dropdown {
        
        position: relative;
        display: inline-block;
    }
    .dropbtn {
        padding: 8px 12px;
        cursor: pointer;
    }
    .dropdown-content {
        display: none;
        position: absolute;
        background-color: #f9f9f9;
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1; 
        left: 0;
        padding: 5px 0;
        border-radius: 5px;
    }
    .dropdown-content a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
        text-align: left;
    }
    .dropdown-content a:hover {
        background-color: #f1f1f1;
        color: #007bff;
    }
    .dropdown:hover .dropdown-content {
        display: block;
    }
</style>

</head>
<body>
    <h1>Selamat Datang di Kampus</h1>
   <nav>
    
    <div class="dropdown">
        <a href="#" class="dropbtn">Data </a>
        <div class="dropdown-content">
            <a href="mahasiswa.php">Mahasiswa</a>
            <a href="dosen.php">Dosen</a>
            <a href="prodi.php">Program Studi</a>
        </div>
    </div>

    <div class="dropdown">
        <a href="#" class="dropbtn">Akademik</a>
        <div class="dropdown-content">
            <a href="matkul.php">Mata Kuliah</a>
            <a href="nilai.php">Nilai</a>
        </div>
    </div>
    
    <a href="pengumuman.php">Pengumuman</a>
    <a href="user.php">User</a>

</nav>

    <h2>selamat datang di website Kampus</h2>
    <p>pilih menu di atas untuk mengelola data.</p>
    
</body>
</html>