<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah Mata Kuliah</title>
    <style>
        body {font-family: Arial; background: #f6f9ff; padding: 20px;}
        form {background: white; padding: 20px; border-radius: 10px; width: 400px;}
        input, select, textarea {width: 100%; padding: 8px; margin: 5px 0;}
        input[type=submit] {background: #007bff; color: white; border: none; padding: 10px;}
        input[type=submit]:hover {background: #0056b3;}
    </style>
</head>
<body>

<h2>Tambah MAtakuliah</h2>

<form method="post">
    Kode MK:
    <input type="text" name="kode_matkul" required>
    Nama MK:
    <input type="text" name="nama_matkul" required>
    Program Studi:
    <select name="id_prodi">
        <?php
        $tb_prodi = mysqli_query($koneksi, "SELECT * FROM tb_prodi");
        while ($p = mysqli_fetch_array($tb_prodi)) {
            echo "<option value='$p[id_prodi]'>$p[nama_prodi]</option>";
        }
        ?>
    </select>
    SKS:
    <input type="text" name="sks" required>
    <input type="submit" name="simpan" value="Simpan Data">
</form>

<?php
if (isset($_POST['simpan'])) {
    $kode_matkul = $_POST['kode_matkul'];
    $nama_matkul = $_POST['nama_matkul'];
    $id_prodi = $_POST['id_prodi'];
    $sks = $_POST['sks'];
    


    mysqli_query($koneksi, "INSERT INTO tb_matkul(kode_matkul, nama_matkul, id_prodi, sks)
                            VALUES ('$kode_matkul', '$nama_matkul', '$id_prodi', '$sks')");
    header("Location: matkul.php");
}
?>

<br>
<a href="matkul.php">← Kembali</a>

</body>
</html>